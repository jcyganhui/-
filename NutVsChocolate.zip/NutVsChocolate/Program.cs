using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace NutVsChocolate
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameForm());
        }
    }

    internal sealed class GameForm : Form
    {
        private const int LaneCount = 5;
        private const int ColumnCount = 7;
        private const int CellWidth = 92;
        private const int CellHeight = 88;
        private const int BoardLeft = 34;
        private const int BoardTop = 110;
        private const int BoardWidth = ColumnCount * CellWidth;
        private const int BoardHeight = LaneCount * CellHeight;
        private const int UiLeft = BoardLeft + BoardWidth + 34;
        private const int RightSpawnX = BoardLeft + BoardWidth + 50;

        private readonly Timer gameTimer;
        private readonly List<NutUnit> nuts = new List<NutUnit>();
        private readonly List<ChocolateEnemy> enemies = new List<ChocolateEnemy>();
        private readonly List<Projectile> projectiles = new List<Projectile>();
        private readonly List<FloatingText> floatingTexts = new List<FloatingText>();
        private readonly List<SpawnEvent> spawnQueue = new List<SpawnEvent>();
        private readonly List<Button> nutButtons = new List<Button>();
        private readonly Random random = new Random();

        private readonly Button startButton;
        private readonly Button retryButton;
        private readonly Button nextLevelButton;
        private readonly ComboBox levelPicker;
        private readonly Label titleLabel;
        private readonly Label infoLabel;
        private readonly Label selectionLabel;

        private int selectedNutIndex;
        private int permanentGold = 100;
        private int unlockedLevel = 1;
        private int currentLevelIndex = 1;
        private int battleEnergy;
        private int rewardGold;
        private float levelTime;
        private float energyClock;
        private bool levelRunning;
        private bool levelWon;
        private bool levelLost;
        private string statusText = "点击开始，守住坚果庄园。";

        public GameForm()
        {
            Text = "坚果大战巧克力";
            ClientSize = new Size(1140, 690);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            DoubleBuffered = true;
            BackColor = Color.FromArgb(250, 242, 224);
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point);

            titleLabel = new Label
            {
                Text = "坚果大战巧克力",
                Font = new Font("Microsoft YaHei UI", 23F, FontStyle.Bold, GraphicsUnit.Point),
                ForeColor = Color.FromArgb(88, 54, 27),
                AutoSize = true,
                Location = new Point(UiLeft, 20),
                BackColor = Color.Transparent
            };
            Controls.Add(titleLabel);

            infoLabel = new Label
            {
                AutoSize = false,
                Size = new Size(390, 132),
                Location = new Point(UiLeft, 78),
                ForeColor = Color.FromArgb(82, 59, 37),
                BackColor = Color.Transparent
            };
            Controls.Add(infoLabel);

            selectionLabel = new Label
            {
                AutoSize = false,
                Size = new Size(390, 24),
                Location = new Point(UiLeft, 220),
                Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold, GraphicsUnit.Point),
                ForeColor = Color.FromArgb(131, 81, 42),
                BackColor = Color.Transparent
            };
            Controls.Add(selectionLabel);

            CreateNutButton(0, "花生射手 50", 252);
            CreateNutButton(1, "核桃盾卫 40", 298);
            CreateNutButton(2, "杏仁狙手 80", 344);
            CreateNutButton(3, "栗子爆破 100", 390);

            levelPicker = CreateComboBox(new Point(UiLeft, 456), new Size(175, 32));
            levelPicker.SelectedIndexChanged += delegate
            {
                if (levelPicker.SelectedIndex >= 0)
                {
                    currentLevelIndex = levelPicker.SelectedIndex + 1;
                    statusText = string.Format("准备挑战第 {0} 关。", currentLevelIndex);
                    UpdateUiText();
                    Invalidate();
                }
            };
            Controls.Add(levelPicker);

            startButton = CreateActionButton("开始关卡", new Point(UiLeft, 504), Color.FromArgb(191, 129, 56));
            startButton.Click += delegate { StartLevel(currentLevelIndex); };
            Controls.Add(startButton);

            retryButton = CreateActionButton("重新挑战", new Point(UiLeft + 126, 504), Color.FromArgb(155, 87, 59));
            retryButton.Click += delegate { StartLevel(currentLevelIndex); };
            Controls.Add(retryButton);

            nextLevelButton = CreateActionButton("下一关", new Point(UiLeft + 252, 504), Color.FromArgb(90, 151, 96));
            nextLevelButton.Click += delegate
            {
                currentLevelIndex = Math.Min(10, currentLevelIndex + 1);
                RefreshLevelPicker();
                StartLevel(currentLevelIndex);
            };
            Controls.Add(nextLevelButton);

            MouseDown += HandleBoardClick;

            gameTimer = new Timer();
            gameTimer.Interval = 33;
            gameTimer.Tick += delegate { TickGame(0.033f); };

            LoadProgress();
            RefreshLevelPicker();
            SelectNut(0);
            UpdateUiText();
        }

        private static ComboBox CreateComboBox(Point location, Size size)
        {
            var comboBox = new ComboBox();
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox.Location = location;
            comboBox.Size = size;
            comboBox.FlatStyle = FlatStyle.Flat;
            comboBox.BackColor = Color.FromArgb(252, 247, 236);
            return comboBox;
        }

        private Button CreateActionButton(string text, Point location, Color backColor)
        {
            var button = new Button();
            button.Text = text;
            button.Location = location;
            button.Size = new Size(112, 38);
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = backColor;
            button.ForeColor = Color.White;
            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private void CreateNutButton(int index, string text, int top)
        {
            var button = new Button();
            button.Text = text;
            button.Location = new Point(UiLeft, top);
            button.Size = new Size(240, 38);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.FromArgb(240, 223, 193);
            button.ForeColor = Color.FromArgb(81, 58, 35);
            button.Click += delegate { SelectNut(index); };
            nutButtons.Add(button);
            Controls.Add(button);
        }

        private void SelectNut(int index)
        {
            selectedNutIndex = index;
            for (var i = 0; i < nutButtons.Count; i++)
            {
                nutButtons[i].BackColor = i == index
                    ? Color.FromArgb(199, 148, 82)
                    : Color.FromArgb(240, 223, 193);
                nutButtons[i].ForeColor = i == index ? Color.White : Color.FromArgb(81, 58, 35);
            }

            selectionLabel.Text = "当前部署卡：" + NutCatalog.Definitions[index].Name;
        }

        private void LoadProgress()
        {
            var savePath = GetSavePath();
            if (!File.Exists(savePath))
            {
                return;
            }

            try
            {
                var parts = File.ReadAllText(savePath).Split('|');
                if (parts.Length >= 2)
                {
                    unlockedLevel = Math.Max(1, Math.Min(10, int.Parse(parts[0])));
                    permanentGold = Math.Max(0, int.Parse(parts[1]));
                }
            }
            catch
            {
                unlockedLevel = 1;
                permanentGold = 100;
            }
        }

        private void SaveProgress()
        {
            File.WriteAllText(GetSavePath(), unlockedLevel + "|" + permanentGold);
        }

        private string GetSavePath()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "player-progress.dat");
        }

        private void RefreshLevelPicker()
        {
            var previous = currentLevelIndex;
            levelPicker.Items.Clear();
            for (var i = 1; i <= unlockedLevel; i++)
            {
                levelPicker.Items.Add("第 " + i + " 关");
            }

            currentLevelIndex = Math.Max(1, Math.Min(previous, unlockedLevel));
            levelPicker.SelectedIndex = currentLevelIndex - 1;
        }

        private void StartLevel(int levelIndex)
        {
            currentLevelIndex = levelIndex;
            nuts.Clear();
            enemies.Clear();
            projectiles.Clear();
            floatingTexts.Clear();
            spawnQueue.Clear();

            var config = LevelFactory.Build(levelIndex);
            spawnQueue.AddRange(config.Spawns.OrderBy(delegate(SpawnEvent spawn) { return spawn.Time; }));
            battleEnergy = config.StartingEnergy;
            rewardGold = config.RewardGold;
            levelTime = 0f;
            energyClock = 0f;
            levelWon = false;
            levelLost = false;
            levelRunning = true;
            statusText = config.Tagline;
            gameTimer.Start();
            UpdateUiText();
            Invalidate();
        }

        private void TickGame(float dt)
        {
            if (!levelRunning)
            {
                return;
            }

            levelTime += dt;
            energyClock += dt;
            var config = LevelFactory.Build(currentLevelIndex);

            while (energyClock >= config.EnergyInterval)
            {
                energyClock -= config.EnergyInterval;
                battleEnergy += config.EnergyPerTick;
            }

            while (spawnQueue.Count > 0 && spawnQueue[0].Time <= levelTime)
            {
                var spawn = spawnQueue[0];
                spawnQueue.RemoveAt(0);
                enemies.Add(ChocolateEnemy.Create(spawn.Type, spawn.Lane, RightSpawnX + random.Next(10, 36)));
            }

            UpdateNuts(dt);
            UpdateProjectiles(dt);
            UpdateEnemies(dt);
            UpdateFloatingTexts(dt);
            CleanupDeadObjects();

            if (!levelLost && spawnQueue.Count == 0 && enemies.Count == 0)
            {
                WinLevel();
            }

            UpdateUiText();
            Invalidate();
        }

        private void UpdateNuts(float dt)
        {
            foreach (var nut in nuts)
            {
                if (!nut.Alive)
                {
                    continue;
                }

                nut.Cooldown -= dt;

                if (nut.Type.Kind == NutKind.Bomber)
                {
                    var closeEnemy = enemies.FirstOrDefault(delegate(ChocolateEnemy enemy)
                    {
                        return enemy.Alive && enemy.Lane == nut.Lane && Math.Abs(enemy.X - nut.X) < 118f;
                    });

                    if (closeEnemy != null && nut.Cooldown <= 0f)
                    {
                        nut.Cooldown = 999f;
                        nut.Alive = false;
                        foreach (var enemy in enemies.Where(delegate(ChocolateEnemy e)
                        {
                            return e.Alive && e.Lane == nut.Lane && Math.Abs(e.X - nut.X) < 154f;
                        }))
                        {
                            enemy.Health -= nut.Type.Damage;
                            floatingTexts.Add(new FloatingText("-" + nut.Type.Damage, enemy.X, LaneCenter(enemy.Lane) - 48f, Color.FromArgb(168, 61, 43)));
                        }

                        floatingTexts.Add(new FloatingText("爆破", nut.X - 8f, LaneCenter(nut.Lane) - 56f, Color.FromArgb(227, 129, 67)));
                    }

                    continue;
                }

                if (nut.Type.Kind == NutKind.Wall)
                {
                    continue;
                }

                var target = enemies.FirstOrDefault(delegate(ChocolateEnemy enemy)
                {
                    return enemy.Alive && enemy.Lane == nut.Lane && enemy.X > nut.X - 12f;
                });

                if (target == null || nut.Cooldown > 0f)
                {
                    continue;
                }

                nut.Cooldown = nut.Type.FireInterval;
                projectiles.Add(new Projectile
                {
                    Lane = nut.Lane,
                    X = nut.X + 18f,
                    Y = LaneCenter(nut.Lane) - 26f,
                    Speed = nut.Type.ProjectileSpeed,
                    Damage = nut.Type.Damage,
                    Radius = nut.Type.Kind == NutKind.Sniper ? 8 : 6,
                    Color = nut.Type.Kind == NutKind.Sniper ? Color.FromArgb(106, 66, 35) : Color.FromArgb(215, 166, 82)
                });
            }
        }

        private void UpdateProjectiles(float dt)
        {
            foreach (var projectile in projectiles)
            {
                if (!projectile.Alive)
                {
                    continue;
                }

                projectile.X += projectile.Speed * dt;

                var hit = enemies.FirstOrDefault(delegate(ChocolateEnemy enemy)
                {
                    return enemy.Alive && enemy.Lane == projectile.Lane && Math.Abs(enemy.X - projectile.X) < 20f;
                });

                if (hit == null)
                {
                    if (projectile.X > BoardLeft + BoardWidth + 100)
                    {
                        projectile.Alive = false;
                    }

                    continue;
                }

                hit.Health -= projectile.Damage;
                projectile.Alive = false;
                floatingTexts.Add(new FloatingText("-" + projectile.Damage, hit.X, LaneCenter(hit.Lane) - 52f, Color.FromArgb(132, 55, 44)));
            }
        }

        private void UpdateEnemies(float dt)
        {
            foreach (var enemy in enemies)
            {
                if (!enemy.Alive)
                {
                    continue;
                }

                enemy.AttackCooldown -= dt;

                var blocker = nuts
                    .Where(delegate(NutUnit nut) { return nut.Alive && nut.Lane == enemy.Lane; })
                    .OrderBy(delegate(NutUnit nut) { return Math.Abs(nut.X - enemy.X); })
                    .FirstOrDefault(delegate(NutUnit nut) { return Math.Abs(nut.X - enemy.X) < 44f; });

                if (blocker != null)
                {
                    if (enemy.AttackCooldown <= 0f)
                    {
                        enemy.AttackCooldown = enemy.Type.AttackInterval;
                        blocker.Health -= enemy.Type.Damage;
                        floatingTexts.Add(new FloatingText("-" + enemy.Type.Damage, blocker.X - 4f, LaneCenter(blocker.Lane) - 50f, Color.FromArgb(116, 41, 34)));
                    }
                }
                else
                {
                    enemy.X -= enemy.Type.Speed * dt;
                }

                if (enemy.X < BoardLeft - 24)
                {
                    LoseLevel();
                    return;
                }
            }
        }

        private void UpdateFloatingTexts(float dt)
        {
            foreach (var text in floatingTexts)
            {
                text.Y -= 20f * dt;
                text.TimeLeft -= dt;
            }
        }

        private void CleanupDeadObjects()
        {
            foreach (var nut in nuts.Where(delegate(NutUnit unit) { return unit.Health <= 0; }))
            {
                nut.Alive = false;
            }

            foreach (var enemy in enemies.Where(delegate(ChocolateEnemy unit) { return unit.Health <= 0; }))
            {
                enemy.Alive = false;
                floatingTexts.Add(new FloatingText("+8", enemy.X - 6f, LaneCenter(enemy.Lane) - 42f, Color.FromArgb(221, 183, 63)));
            }

            nuts.RemoveAll(delegate(NutUnit unit) { return !unit.Alive; });
            enemies.RemoveAll(delegate(ChocolateEnemy unit) { return !unit.Alive; });
            projectiles.RemoveAll(delegate(Projectile shot) { return !shot.Alive; });
            floatingTexts.RemoveAll(delegate(FloatingText text) { return text.TimeLeft <= 0f; });
        }

        private void WinLevel()
        {
            levelRunning = false;
            levelWon = true;
            gameTimer.Stop();
            permanentGold += rewardGold;
            if (currentLevelIndex < 10)
            {
                unlockedLevel = Math.Max(unlockedLevel, currentLevelIndex + 1);
            }

            statusText = string.Format("第 {0} 关胜利，获得 {1} 金币。", currentLevelIndex, rewardGold);
            SaveProgress();
            RefreshLevelPicker();
        }

        private void LoseLevel()
        {
            levelRunning = false;
            levelLost = true;
            gameTimer.Stop();
            statusText = string.Format("第 {0} 关失败，巧克力突破了防线。", currentLevelIndex);
        }

        private void UpdateUiText()
        {
            var config = LevelFactory.Build(currentLevelIndex);
            var levelState = levelRunning
                ? "进行中 " + Math.Min(100, (int)(levelTime / config.Duration * 100f)) + "%"
                : levelWon
                    ? "已通关"
                    : levelLost ? "失败" : "待开始";

            infoLabel.Text =
                "总金币：" + permanentGold + Environment.NewLine +
                "已解锁：" + unlockedLevel + " / 10 关" + Environment.NewLine +
                "当前能量：" + battleEnergy + Environment.NewLine +
                "本关奖励：" + rewardGold + " 金币" + Environment.NewLine +
                "局面状态：" + levelState + Environment.NewLine +
                "关卡主题：" + config.Tagline;

            nextLevelButton.Enabled = levelWon && currentLevelIndex < unlockedLevel;
        }

        private void HandleBoardClick(object sender, MouseEventArgs e)
        {
            if (!levelRunning)
            {
                return;
            }

            if (e.X < BoardLeft || e.X > BoardLeft + BoardWidth || e.Y < BoardTop || e.Y > BoardTop + BoardHeight)
            {
                return;
            }

            var lane = (e.Y - BoardTop) / CellHeight;
            var column = (e.X - BoardLeft) / CellWidth;
            if (lane < 0 || lane >= LaneCount || column < 0 || column >= ColumnCount)
            {
                return;
            }

            if (nuts.Any(delegate(NutUnit unit) { return unit.Alive && unit.Lane == lane && unit.Column == column; }))
            {
                statusText = "这个格子已经有坚果驻守。";
                return;
            }

            var definition = NutCatalog.Definitions[selectedNutIndex];
            if (battleEnergy < definition.Cost)
            {
                statusText = "战斗能量不足。";
                return;
            }

            battleEnergy -= definition.Cost;
            nuts.Add(new NutUnit
            {
                Type = definition,
                Lane = lane,
                Column = column,
                X = CellCenterX(column),
                Health = definition.MaxHealth,
                Cooldown = 0.16f,
                Alive = true
            });
            statusText = definition.Name + " 已部署到第 " + (lane + 1) + " 路。";
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            DrawBackdrop(g);
            DrawBoardFrame(g);
            DrawBoard(g);
            DrawProjectiles(g);
            DrawUnits(g);
            DrawHudPanels(g);
            DrawProgressBar(g);
            DrawOverlay(g);
        }

        private void DrawBackdrop(Graphics g)
        {
            using (var sky = new LinearGradientBrush(ClientRectangle, Color.FromArgb(255, 225, 188), Color.FromArgb(242, 236, 210), 90f))
            {
                g.FillRectangle(sky, ClientRectangle);
            }

            using (var groundBrush = new LinearGradientBrush(new Rectangle(0, BoardTop - 16, Width, Height - BoardTop + 16), Color.FromArgb(195, 218, 156), Color.FromArgb(137, 175, 110), 90f))
            {
                g.FillRectangle(groundBrush, new Rectangle(0, BoardTop - 16, Width, Height - BoardTop + 16));
            }

            using (var panelBrush = new SolidBrush(Color.FromArgb(55, 255, 255, 255)))
            {
                g.FillEllipse(panelBrush, -120, -90, 420, 210);
                g.FillEllipse(panelBrush, BoardLeft + 210, 8, 260, 90);
            }

            using (var titleBrush = new SolidBrush(Color.FromArgb(96, 58, 29)))
            {
                g.DrawString(statusText, new Font("Microsoft YaHei UI", 10.5F, FontStyle.Bold), titleBrush, new RectangleF(BoardLeft, 24, BoardWidth + 90, 28));
            }
        }

        private void DrawBoardFrame(Graphics g)
        {
            var frame = new Rectangle(BoardLeft - 14, BoardTop - 18, BoardWidth + 28, BoardHeight + 48);
            using (var shadow = new SolidBrush(Color.FromArgb(65, 68, 47, 25)))
            {
                g.FillRoundedRectangle(shadow, new Rectangle(frame.X + 10, frame.Y + 18, frame.Width, frame.Height), 26);
            }

            using (var wood = new LinearGradientBrush(frame, Color.FromArgb(138, 93, 51), Color.FromArgb(104, 69, 38), 90f))
            {
                g.FillRoundedRectangle(wood, frame, 26);
            }

            using (var lip = new SolidBrush(Color.FromArgb(191, 144, 88)))
            {
                g.FillRoundedRectangle(lip, new Rectangle(frame.X + 10, frame.Y + 10, frame.Width - 20, 18), 10);
            }
        }

        private void DrawBoard(Graphics g)
        {
            var boardRect = new Rectangle(BoardLeft, BoardTop, BoardWidth, BoardHeight);
            using (var field = new LinearGradientBrush(boardRect, Color.FromArgb(169, 207, 120), Color.FromArgb(119, 166, 91), 90f))
            {
                g.FillRoundedRectangle(field, boardRect, 18);
            }

            for (var row = 0; row < LaneCount; row++)
            {
                for (var col = 0; col < ColumnCount; col++)
                {
                    DrawCell(g, row, col);
                }
            }

            using (var laneBrush = new SolidBrush(Color.FromArgb(90, 89, 116, 63)))
            {
                for (var row = 0; row < LaneCount; row++)
                {
                    g.FillEllipse(laneBrush, BoardLeft + 22, BoardTop + row * CellHeight + 58, BoardWidth - 44, 18);
                }
            }

            using (var rowText = new SolidBrush(Color.FromArgb(73, 90, 48)))
            {
                for (var row = 0; row < LaneCount; row++)
                {
                    g.DrawString("路 " + (row + 1), Font, rowText, BoardLeft - 2, BoardTop + row * CellHeight + 10);
                }
            }
        }

        private void DrawCell(Graphics g, int row, int col)
        {
            var x = BoardLeft + col * CellWidth;
            var y = BoardTop + row * CellHeight;
            var top = new[]
            {
                new Point(x + 9, y + 18),
                new Point(x + CellWidth - 9, y + 18),
                new Point(x + CellWidth - 20, y + 35),
                new Point(x + 20, y + 35)
            };
            var front = new[]
            {
                new Point(x + 20, y + 35),
                new Point(x + CellWidth - 20, y + 35),
                new Point(x + CellWidth - 14, y + CellHeight - 12),
                new Point(x + 14, y + CellHeight - 12)
            };

            var topColor = (row + col) % 2 == 0 ? Color.FromArgb(197, 227, 144) : Color.FromArgb(181, 214, 132);
            var frontColor = (row + col) % 2 == 0 ? Color.FromArgb(149, 193, 99) : Color.FromArgb(138, 181, 92);

            using (var topBrush = new SolidBrush(topColor))
            using (var frontBrush = new SolidBrush(frontColor))
            using (var linePen = new Pen(Color.FromArgb(96, 122, 72), 2f))
            {
                g.FillPolygon(topBrush, top);
                g.FillPolygon(frontBrush, front);
                g.DrawPolygon(linePen, top);
                g.DrawPolygon(linePen, front);
            }

            using (var stripe = new Pen(Color.FromArgb(48, 255, 255, 255), 1.2f))
            {
                g.DrawLine(stripe, x + 22, y + 39, x + CellWidth - 18, y + 39);
                g.DrawLine(stripe, x + 18, y + 54, x + CellWidth - 16, y + 54);
            }
        }

        private void DrawProjectiles(Graphics g)
        {
            foreach (var projectile in projectiles)
            {
                using (var shadow = new SolidBrush(Color.FromArgb(70, 70, 46, 24)))
                {
                    g.FillEllipse(shadow, projectile.X - projectile.Radius + 2f, projectile.Y + 24f, projectile.Radius * 2, projectile.Radius + 4);
                }

                using (var shotBrush = new SolidBrush(projectile.Color))
                using (var shine = new SolidBrush(Color.FromArgb(170, 255, 247, 228)))
                {
                    g.FillEllipse(shotBrush, projectile.X - projectile.Radius, projectile.Y - projectile.Radius, projectile.Radius * 2, projectile.Radius * 2);
                    g.FillEllipse(shine, projectile.X - projectile.Radius / 2f, projectile.Y - projectile.Radius / 2f - 1f, projectile.Radius, projectile.Radius);
                }
            }
        }

        private void DrawUnits(Graphics g)
        {
            foreach (var nut in nuts)
            {
                DrawNut(g, nut);
            }

            foreach (var enemy in enemies)
            {
                DrawEnemy(g, enemy);
            }

            foreach (var text in floatingTexts)
            {
                using (var glow = new SolidBrush(Color.FromArgb(70, 255, 255, 255)))
                using (var brush = new SolidBrush(text.Color))
                {
                    g.DrawString(text.Text, new Font("Microsoft YaHei UI", 9F, FontStyle.Bold), glow, text.X + 1f, text.Y + 1f);
                    g.DrawString(text.Text, new Font("Microsoft YaHei UI", 9F, FontStyle.Bold), brush, text.X, text.Y);
                }
            }
        }

        private void DrawNut(Graphics g, NutUnit nut)
        {
            var y = LaneCenter(nut.Lane);
            using (var shadow = new SolidBrush(Color.FromArgb(72, 52, 39, 24)))
            {
                g.FillEllipse(shadow, nut.X - 28f, y + 21f, 60, 14);
            }

            var bodyRect = new RectangleF(nut.X - 28f, y - 42f, 56, 58);
            using (var body = new LinearGradientBrush(Rectangle.Round(bodyRect), nut.Type.Color, ControlPaint.Dark(nut.Type.Color, 0.18f), 90f))
            using (var shine = new SolidBrush(Color.FromArgb(155, 255, 244, 224)))
            using (var detail = new SolidBrush(Color.FromArgb(92, 57, 36)))
            {
                g.FillEllipse(body, bodyRect);
                g.FillEllipse(shine, nut.X - 18f, y - 35f, 16, 14);
                g.FillEllipse(detail, nut.X - 11f, y - 18f, 7, 7);
                g.FillEllipse(detail, nut.X + 4f, y - 18f, 7, 7);
            }

            if (nut.Type.Kind == NutKind.Shooter || nut.Type.Kind == NutKind.Sniper)
            {
                using (var muzzle = new SolidBrush(ControlPaint.Dark(nut.Type.Color, 0.35f)))
                {
                    g.FillEllipse(muzzle, nut.X + 14f, y - 18f, 14, 12);
                }
            }

            if (nut.Type.Kind == NutKind.Wall)
            {
                using (var shell = new Pen(Color.FromArgb(111, 73, 43), 2f))
                {
                    g.DrawArc(shell, nut.X - 16f, y - 10f, 30, 22, 180, 180);
                }
            }

            if (nut.Type.Kind == NutKind.Bomber)
            {
                using (var fuse = new Pen(Color.FromArgb(84, 47, 28), 2f))
                using (var spark = new SolidBrush(Color.FromArgb(245, 193, 78)))
                {
                    g.DrawLine(fuse, nut.X + 6f, y - 34f, nut.X + 14f, y - 46f);
                    g.FillEllipse(spark, nut.X + 11f, y - 49f, 7, 7);
                }
            }

            DrawHealthBar(g, nut.X - 26f, y - 52f, 52f, nut.Health / (float)nut.Type.MaxHealth, Color.FromArgb(79, 150, 69));
            DrawNamePlate(g, nut.Type.ShortName, nut.X - 19f, y + 4f, Color.FromArgb(255, 247, 225));
        }

        private void DrawEnemy(Graphics g, ChocolateEnemy enemy)
        {
            var y = LaneCenter(enemy.Lane);
            using (var shadow = new SolidBrush(Color.FromArgb(76, 48, 35, 28)))
            {
                g.FillEllipse(shadow, enemy.X - 30f, y + 22f, 64, 14);
            }

            var bodyRect = new RectangleF(enemy.X - 26f, y - 42f, 54, 58);
            using (var body = new LinearGradientBrush(Rectangle.Round(bodyRect), enemy.Type.Color, ControlPaint.Dark(enemy.Type.Color, 0.22f), 90f))
            using (var glaze = new SolidBrush(Color.FromArgb(90, 255, 235, 215)))
            using (var cream = new SolidBrush(Color.FromArgb(255, 241, 218)))
            {
                g.FillRoundedRectangle(body, Rectangle.Round(bodyRect), 12);
                g.FillRectangle(glaze, enemy.X - 16f, y - 33f, 14, 40);
                g.FillEllipse(cream, enemy.X - 8f, y - 17f, 7, 7);
                g.FillEllipse(cream, enemy.X + 5f, y - 17f, 7, 7);
            }

            if (enemy.Type.Kind == ChocolateKind.Toffee || enemy.Type.Kind == ChocolateKind.Boss)
            {
                using (var armor = new Pen(Color.FromArgb(208, 174, 123), 3f))
                {
                    g.DrawLine(armor, enemy.X - 18f, y - 5f, enemy.X + 18f, y - 5f);
                    g.DrawArc(armor, enemy.X - 14f, y - 28f, 28, 18, 180, 180);
                }
            }

            if (enemy.Type.Kind == ChocolateKind.Boss)
            {
                using (var crown = new SolidBrush(Color.FromArgb(233, 193, 78)))
                {
                    var points = new[]
                    {
                        new PointF(enemy.X - 14f, y - 36f),
                        new PointF(enemy.X - 8f, y - 50f),
                        new PointF(enemy.X, y - 38f),
                        new PointF(enemy.X + 8f, y - 50f),
                        new PointF(enemy.X + 14f, y - 36f)
                    };
                    g.FillPolygon(crown, points);
                }
            }

            DrawHealthBar(g, enemy.X - 24f, y - 52f, 48f, enemy.Health / (float)enemy.Type.MaxHealth, Color.FromArgb(182, 72, 60));
            DrawNamePlate(g, enemy.Type.ShortName, enemy.X - 18f, y + 4f, Color.FromArgb(255, 248, 238));
        }

        private void DrawHudPanels(Graphics g)
        {
            var topPanel = new Rectangle(UiLeft - 12, 12, 392, 210);
            var cardPanel = new Rectangle(UiLeft - 12, 232, 392, 204);
            var controlPanel = new Rectangle(UiLeft - 12, 446, 392, 132);

            DrawGlassPanel(g, topPanel);
            DrawGlassPanel(g, cardPanel);
            DrawGlassPanel(g, controlPanel);

            using (var brush = new SolidBrush(Color.FromArgb(132, 86, 49)))
            {
                g.DrawString("布阵卡组", new Font("Microsoft YaHei UI", 11F, FontStyle.Bold), brush, UiLeft, 242);
                g.DrawString("关卡控制", new Font("Microsoft YaHei UI", 11F, FontStyle.Bold), brush, UiLeft, 454);
            }

            for (var i = 0; i < NutCatalog.Definitions.Length; i++)
            {
                DrawPreviewCard(g, NutCatalog.Definitions[i], i, UiLeft + 250, 251 + i * 46);
            }

            using (var hintBrush = new SolidBrush(Color.FromArgb(101, 74, 47)))
            {
                g.DrawString("玩法提示：选择坚果后点击左侧草地格子布阵。", Font, hintBrush, UiLeft, 590);
            }
        }

        private void DrawPreviewCard(Graphics g, NutDefinition definition, int index, int x, int y)
        {
            var active = index == selectedNutIndex;
            using (var brush = new SolidBrush(active ? Color.FromArgb(238, 203, 136) : Color.FromArgb(248, 239, 217)))
            using (var edge = new Pen(active ? Color.FromArgb(202, 150, 74) : Color.FromArgb(221, 196, 161), 1.5f))
            {
                g.FillRoundedRectangle(brush, new Rectangle(x, y, 114, 34), 12);
                g.DrawRoundedRectangle(edge, new Rectangle(x, y, 114, 34), 12);
            }

            using (var icon = new SolidBrush(definition.Color))
            using (var textBrush = new SolidBrush(Color.FromArgb(92, 60, 34)))
            {
                g.FillEllipse(icon, x + 8, y + 7, 20, 20);
                g.DrawString(definition.ShortName, new Font("Microsoft YaHei UI", 8F, FontStyle.Bold), textBrush, x + 34, y + 8);
                g.DrawString("能量 " + definition.Cost, new Font("Microsoft YaHei UI", 7.5F, FontStyle.Regular), textBrush, x + 34, y + 18);
            }
        }

        private void DrawProgressBar(Graphics g)
        {
            var barX = BoardLeft + 6;
            var barY = BoardTop + BoardHeight + 20;
            var barWidth = BoardWidth - 12;
            var config = LevelFactory.Build(currentLevelIndex);
            var progress = levelRunning ? Math.Max(0f, Math.Min(1f, levelTime / config.Duration)) : levelWon ? 1f : 0f;

            using (var baseBrush = new SolidBrush(Color.FromArgb(68, 77, 63, 37)))
            using (var fillBrush = new LinearGradientBrush(new Rectangle(barX, barY, barWidth, 16), Color.FromArgb(251, 215, 96), Color.FromArgb(230, 141, 56), 0f))
            {
                g.FillRoundedRectangle(baseBrush, new Rectangle(barX, barY, barWidth, 16), 8);
                g.FillRoundedRectangle(fillBrush, new Rectangle(barX, barY, (int)(barWidth * progress), 16), 8);
            }

            using (var textBrush = new SolidBrush(Color.FromArgb(247, 244, 233)))
            {
                g.DrawString("巧克力攻势", new Font("Microsoft YaHei UI", 9F, FontStyle.Bold), textBrush, barX + 12, barY - 1);
            }
        }

        private void DrawOverlay(Graphics g)
        {
            if (levelRunning)
            {
                return;
            }

            var panel = new Rectangle(BoardLeft + 70, BoardTop + 120, BoardWidth - 140, 190);
            using (var shadow = new SolidBrush(Color.FromArgb(72, 42, 24, 16)))
            {
                g.FillRoundedRectangle(shadow, new Rectangle(panel.X + 8, panel.Y + 10, panel.Width, panel.Height), 22);
            }

            using (var overlay = new LinearGradientBrush(panel, Color.FromArgb(198, 82, 54, 39), Color.FromArgb(168, 58, 37, 29), 90f))
            {
                g.FillRoundedRectangle(overlay, panel, 22);
            }

            var headline = levelWon ? "胜利" : levelLost ? "失败" : "开始冒险";
            var body = levelWon
                ? "你守住了本轮甜点攻势，下一关的巧克力会更强。"
                : levelLost
                    ? "巧克力冲破了最左侧防线，调整阵型后继续挑战。"
                    : "先选坚果，再点击草地格子进行部署。";

            using (var white = new SolidBrush(Color.White))
            {
                g.DrawString(headline, new Font("Microsoft YaHei UI", 28F, FontStyle.Bold), white, panel.X + 260, panel.Y + 26);
                g.DrawString(body, new Font("Microsoft YaHei UI", 12F, FontStyle.Regular), white, new RectangleF(panel.X + 68, panel.Y + 88, panel.Width - 136, 60));
            }
        }

        private void DrawGlassPanel(Graphics g, Rectangle rect)
        {
            using (var shadow = new SolidBrush(Color.FromArgb(34, 44, 28, 16)))
            {
                g.FillRoundedRectangle(shadow, new Rectangle(rect.X + 6, rect.Y + 8, rect.Width, rect.Height), 22);
            }

            using (var fill = new SolidBrush(Color.FromArgb(198, 255, 248, 234)))
            using (var edge = new Pen(Color.FromArgb(170, 217, 189, 150), 1.5f))
            {
                g.FillRoundedRectangle(fill, rect, 22);
                g.DrawRoundedRectangle(edge, rect, 22);
            }

            using (var shine = new SolidBrush(Color.FromArgb(54, 255, 255, 255)))
            {
                g.FillRoundedRectangle(shine, new Rectangle(rect.X + 12, rect.Y + 10, rect.Width - 24, 26), 12);
            }
        }

        private void DrawHealthBar(Graphics g, float x, float y, float width, float ratio, Color fillColor)
        {
            ratio = Math.Max(0f, Math.Min(1f, ratio));
            using (var back = new SolidBrush(Color.FromArgb(94, 57, 39)))
            using (var fill = new SolidBrush(fillColor))
            {
                g.FillRoundedRectangle(back, new Rectangle((int)x, (int)y, (int)width, 7), 3);
                g.FillRoundedRectangle(fill, new Rectangle((int)x, (int)y, (int)(width * ratio), 7), 3);
            }
        }

        private void DrawNamePlate(Graphics g, string text, float x, float y, Color textColor)
        {
            using (var shadow = new SolidBrush(Color.FromArgb(70, 54, 33, 19)))
            {
                g.FillRoundedRectangle(shadow, new Rectangle((int)x - 2, (int)y + 2, 40, 16), 8);
            }

            using (var plate = new SolidBrush(Color.FromArgb(180, 255, 255, 255)))
            {
                g.FillRoundedRectangle(plate, new Rectangle((int)x - 4, (int)y, 40, 16), 8);
            }

            using (var brush = new SolidBrush(textColor))
            {
                g.DrawString(text, new Font("Microsoft YaHei UI", 7.7F, FontStyle.Bold), brush, x, y + 1f);
            }
        }

        private static float CellCenterX(int column)
        {
            return BoardLeft + column * CellWidth + CellWidth / 2f;
        }

        private static float LaneCenter(int lane)
        {
            return BoardTop + lane * CellHeight + CellHeight / 2f + 6f;
        }
    }

    internal enum NutKind
    {
        Shooter,
        Wall,
        Sniper,
        Bomber
    }

    internal sealed class NutDefinition
    {
        public string Name { get; set; }
        public string ShortName { get; set; }
        public NutKind Kind { get; set; }
        public int Cost { get; set; }
        public int MaxHealth { get; set; }
        public int Damage { get; set; }
        public float FireInterval { get; set; }
        public float ProjectileSpeed { get; set; }
        public Color Color { get; set; }
    }

    internal static class NutCatalog
    {
        public static readonly NutDefinition[] Definitions =
        {
            new NutDefinition
            {
                Name = "花生射手",
                ShortName = "花生",
                Kind = NutKind.Shooter,
                Cost = 50,
                MaxHealth = 82,
                Damage = 16,
                FireInterval = 0.9f,
                ProjectileSpeed = 326f,
                Color = Color.FromArgb(196, 140, 81)
            },
            new NutDefinition
            {
                Name = "核桃盾卫",
                ShortName = "核桃",
                Kind = NutKind.Wall,
                Cost = 40,
                MaxHealth = 228,
                Damage = 0,
                FireInterval = 99f,
                ProjectileSpeed = 0f,
                Color = Color.FromArgb(158, 106, 72)
            },
            new NutDefinition
            {
                Name = "杏仁狙手",
                ShortName = "杏仁",
                Kind = NutKind.Sniper,
                Cost = 80,
                MaxHealth = 62,
                Damage = 34,
                FireInterval = 1.22f,
                ProjectileSpeed = 442f,
                Color = Color.FromArgb(228, 184, 118)
            },
            new NutDefinition
            {
                Name = "栗子爆破",
                ShortName = "栗子",
                Kind = NutKind.Bomber,
                Cost = 100,
                MaxHealth = 56,
                Damage = 95,
                FireInterval = 99f,
                ProjectileSpeed = 0f,
                Color = Color.FromArgb(136, 84, 49)
            }
        };
    }

    internal enum ChocolateKind
    {
        Milk,
        Dark,
        Toffee,
        Boss
    }

    internal sealed class ChocolateDefinition
    {
        public string Name { get; set; }
        public string ShortName { get; set; }
        public ChocolateKind Kind { get; set; }
        public int MaxHealth { get; set; }
        public int Damage { get; set; }
        public float Speed { get; set; }
        public float AttackInterval { get; set; }
        public Color Color { get; set; }
    }

    internal static class ChocolateCatalog
    {
        public static readonly Dictionary<ChocolateKind, ChocolateDefinition> Definitions = new Dictionary<ChocolateKind, ChocolateDefinition>
        {
            {
                ChocolateKind.Milk,
                new ChocolateDefinition
                {
                    Name = "牛奶巧克力",
                    ShortName = "牛奶",
                    Kind = ChocolateKind.Milk,
                    MaxHealth = 66,
                    Damage = 14,
                    Speed = 22f,
                    AttackInterval = 1.0f,
                    Color = Color.FromArgb(126, 79, 54)
                }
            },
            {
                ChocolateKind.Dark,
                new ChocolateDefinition
                {
                    Name = "黑巧突袭者",
                    ShortName = "黑巧",
                    Kind = ChocolateKind.Dark,
                    MaxHealth = 112,
                    Damage = 18,
                    Speed = 18f,
                    AttackInterval = 0.95f,
                    Color = Color.FromArgb(84, 51, 44)
                }
            },
            {
                ChocolateKind.Toffee,
                new ChocolateDefinition
                {
                    Name = "太妃重甲",
                    ShortName = "太妃",
                    Kind = ChocolateKind.Toffee,
                    MaxHealth = 188,
                    Damage = 25,
                    Speed = 12f,
                    AttackInterval = 1.14f,
                    Color = Color.FromArgb(162, 101, 62)
                }
            },
            {
                ChocolateKind.Boss,
                new ChocolateDefinition
                {
                    Name = "可可领主",
                    ShortName = "领主",
                    Kind = ChocolateKind.Boss,
                    MaxHealth = 360,
                    Damage = 33,
                    Speed = 11f,
                    AttackInterval = 0.84f,
                    Color = Color.FromArgb(68, 39, 34)
                }
            }
        };
    }

    internal sealed class NutUnit
    {
        public NutDefinition Type { get; set; }
        public int Lane { get; set; }
        public int Column { get; set; }
        public float X { get; set; }
        public int Health { get; set; }
        public float Cooldown { get; set; }
        public bool Alive { get; set; }
    }

    internal sealed class ChocolateEnemy
    {
        public ChocolateDefinition Type { get; set; }
        public int Lane { get; set; }
        public float X { get; set; }
        public int Health { get; set; }
        public float AttackCooldown { get; set; }
        public bool Alive { get; set; }

        public static ChocolateEnemy Create(ChocolateKind kind, int lane, float x)
        {
            var definition = ChocolateCatalog.Definitions[kind];
            return new ChocolateEnemy
            {
                Type = definition,
                Lane = lane,
                X = x,
                Health = definition.MaxHealth,
                AttackCooldown = 0.4f,
                Alive = true
            };
        }
    }

    internal sealed class Projectile
    {
        public int Lane { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public float Speed { get; set; }
        public int Damage { get; set; }
        public bool Alive { get; set; }
        public Color Color { get; set; }
        public int Radius { get; set; }
    }

    internal sealed class FloatingText
    {
        public FloatingText(string text, float x, float y, Color color)
        {
            Text = text;
            X = x;
            Y = y;
            Color = color;
            TimeLeft = 0.8f;
        }

        public string Text { get; private set; }
        public float X { get; private set; }
        public float Y { get; set; }
        public float TimeLeft { get; set; }
        public Color Color { get; private set; }
    }

    internal sealed class SpawnEvent
    {
        public float Time { get; set; }
        public int Lane { get; set; }
        public ChocolateKind Type { get; set; }
    }

    internal sealed class LevelConfig
    {
        public int RewardGold { get; set; }
        public int StartingEnergy { get; set; }
        public int EnergyPerTick { get; set; }
        public float EnergyInterval { get; set; }
        public float Duration { get; set; }
        public string Tagline { get; set; }
        public List<SpawnEvent> Spawns { get; private set; }

        public LevelConfig()
        {
            Spawns = new List<SpawnEvent>();
        }
    }

    internal static class LevelFactory
    {
        public static LevelConfig Build(int level)
        {
            var random = new Random(1000 + level * 17);
            var config = new LevelConfig
            {
                RewardGold = 25 + level * 15,
                StartingEnergy = 140 + level * 18,
                EnergyPerTick = 12 + level / 3,
                EnergyInterval = Math.Max(0.52f, 0.85f - level * 0.03f),
                Duration = 32f + level * 3.8f,
                Tagline = GetTagline(level)
            };

            var waves = 8 + level * 2;
            for (var i = 0; i < waves; i++)
            {
                var time = 2f + i * (config.Duration - 4f) / waves;
                config.Spawns.Add(new SpawnEvent
                {
                    Time = time,
                    Lane = random.Next(0, 5),
                    Type = ChocolateKind.Milk
                });

                if (level >= 2 && i % 3 == 1)
                {
                    config.Spawns.Add(new SpawnEvent
                    {
                        Time = time + 0.9f,
                        Lane = random.Next(0, 5),
                        Type = ChocolateKind.Dark
                    });
                }

                if (level >= 4 && i % 4 == 2)
                {
                    config.Spawns.Add(new SpawnEvent
                    {
                        Time = time + 1.5f,
                        Lane = random.Next(0, 5),
                        Type = ChocolateKind.Toffee
                    });
                }
            }

            if (level >= 7)
            {
                for (var i = 0; i < 3; i++)
                {
                    config.Spawns.Add(new SpawnEvent
                    {
                        Time = config.Duration - 8f + i * 1.2f,
                        Lane = i % 2 == 0 ? random.Next(0, 5) : 2,
                        Type = ChocolateKind.Toffee
                    });
                }
            }

            if (level == 10)
            {
                config.Spawns.Add(new SpawnEvent
                {
                    Time = config.Duration - 6f,
                    Lane = 2,
                    Type = ChocolateKind.Boss
                });
                config.RewardGold = 260;
                config.Tagline = "终局之战：可可领主率领重甲巧克力发动总攻。";
            }

            config.Spawns.Sort(delegate(SpawnEvent a, SpawnEvent b) { return a.Time.CompareTo(b.Time); });
            return config;
        }

        private static string GetTagline(int level)
        {
            switch (level)
            {
                case 1:
                    return "入门防守：牛奶巧克力开始试探进攻。";
                case 2:
                    return "双线压力：黑巧开始混入队伍。";
                case 3:
                    return "稳住节奏：多路小股进攻更频繁。";
                case 4:
                    return "太妃登场：重甲敌人首次出现。";
                case 5:
                    return "中盘试炼：更讲究前后排配置。";
                case 6:
                    return "硬仗来临：黑巧与太妃同步推进。";
                case 7:
                    return "高压连冲：末段会有连续重甲。";
                case 8:
                    return "阵线拉满：每一路都可能遭遇突袭。";
                case 9:
                    return "决战前夜：资源更快，敌军更狠。";
                case 10:
                    return "终局之战：可可领主率领重甲巧克力发动总攻。";
                default:
                    return "守住左侧防线，别让甜点军团靠近庄园。";
            }
        }
    }

    internal static class GraphicsExtensions
    {
        public static void FillRoundedRectangle(this Graphics graphics, Brush brush, Rectangle bounds, int radius)
        {
            using (var path = CreateRoundedPath(bounds, radius))
            {
                graphics.FillPath(brush, path);
            }
        }

        public static void DrawRoundedRectangle(this Graphics graphics, Pen pen, Rectangle bounds, int radius)
        {
            using (var path = CreateRoundedPath(bounds, radius))
            {
                graphics.DrawPath(pen, path);
            }
        }

        private static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
        {
            var diameter = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}

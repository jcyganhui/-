坚果大战巧克力

运行方式
1. 进入当前目录后执行：
   powershell -ExecutionPolicy Bypass -File .\build.ps1
2. 编译完成后会生成 NutVsChocolate.exe
3. 双击 NutVsChocolate.exe 即可开始游戏

本次升级
- 视觉风格升级为 2.5D 质感，草地棋盘带有立体厚度和斜面层次
- 坚果与巧克力单位增加阴影、高光、铭牌和体积感
- 右侧面板改成更完整的卡组和控制面板风格

游戏说明
- 左侧为 5 路战场，右侧选择坚果后点击格子布阵
- 一共 10 关，通关获得金币并自动解锁下一关
- 游戏进度保存在 exe 同目录的 player-progress.dat

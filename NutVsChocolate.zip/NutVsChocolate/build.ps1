$ErrorActionPreference = "Stop"
$sdkCompiler = "C:\Program Files\dotnet\sdk\6.0.410\Roslyn\bincore\csc.dll"
$framework = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319"
$output = Join-Path $PSScriptRoot "NutVsChocolate.exe"
$source = Join-Path $PSScriptRoot "Program.cs"

$refs = @(
    "/r:$framework\mscorlib.dll",
    "/r:$framework\System.dll",
    "/r:$framework\System.Core.dll",
    "/r:$framework\System.Drawing.dll",
    "/r:$framework\System.Windows.Forms.dll"
)

$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE = "1"
& dotnet $sdkCompiler /nologo /target:winexe /out:$output $refs $source

if (-not (Test-Path $output)) {
    throw "Build failed: $output was not created."
}

Write-Host "Build complete: $output"
